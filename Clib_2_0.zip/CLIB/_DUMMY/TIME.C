/* time function -- dummy version */
#include <time.h>

time_t (time)(time_t *tod)
	{	/* return calendar time */
	return (-1);
	}
