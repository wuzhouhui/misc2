/* toupper function */
#include <ctype.h>

int (toupper)(int c)
	{	/* convert to uppercase character */
	return (_Toupper[c]);
	}
