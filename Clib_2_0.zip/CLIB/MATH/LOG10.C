/* log10 function */
#include <math.h>

double (log10)(double x)
	{	/* compute log10(x) */
	return (_Log(x, 1));
	}
