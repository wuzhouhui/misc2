/* cos function */
#include <math.h>

double (cos)(double x)
	{	/* compute cos */
	return (_Sin(x, 1));
	}
