/* sin function */
#include <math.h>

double (sin)(double x)
	{	/* compute sin */
	return (_Sin(x, 0));
	}
