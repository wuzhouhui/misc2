/* acos function */
#include <math.h>

double (acos)(double x)
	{	/* compute acos(x) */
	return (_Asin(x, 1));
	}
