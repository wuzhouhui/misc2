/* log function */
#include <math.h>

double (log)(double x)
	{	/* compute ln(x) */
	return (_Log(x, 0));
	}
