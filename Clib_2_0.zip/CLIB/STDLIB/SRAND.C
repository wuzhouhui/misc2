/* srand function */
#include <stdlib.h>

void (srand)(unsigned int seed)
	{	/* alter the seed */
	_Randseed = seed;
	}
