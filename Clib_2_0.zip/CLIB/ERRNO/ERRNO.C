/* errno storage */
#include <errno.h>
#undef errno

int errno = 0;
