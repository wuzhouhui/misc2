#include	"unpifi.h"
#include	"ntp.h"

void	 sntp_proc(char *, ssize_t, struct timeval *);
